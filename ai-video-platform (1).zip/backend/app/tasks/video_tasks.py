import asyncio
import time
from uuid import UUID
from datetime import datetime

import httpx
from celery import shared_task
from sqlalchemy import select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession

from app.core.config import get_settings
from app.models.video import VideoGeneration
from app.services.ai_providers import get_provider
from app.services.storage import StorageService

settings = get_settings()


@shared_task(bind=True, max_retries=3, default_retry_delay=30)
def generate_video_task(self, generation_id: str):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(_generate_video_async(generation_id))
    except Exception as exc:
        raise self.retry(exc=exc)
    finally:
        loop.close()


async def _generate_video_async(generation_id: str):
    engine = create_async_engine(settings.DATABASE_URL, future=True)
    async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    async with async_session() as db:
        result = await db.execute(
            select(VideoGeneration).where(VideoGeneration.id == UUID(generation_id))
        )
        generation = result.scalar_one_or_none()

        if not generation:
            return {"error": "Generation not found"}

        if generation.status not in ("pending", "processing"):
            return {"status": generation.status}

        generation.status = "processing"
        generation.started_at = datetime.utcnow()
        await db.commit()

        provider = None
        try:
            provider = get_provider(generation.provider)

            result = await provider.generate(
                prompt=generation.prompt,
                negative_prompt=generation.negative_prompt,
                source_image_url=generation.source_image_url,
                width=generation.width,
                height=generation.height,
                duration_seconds=generation.duration_seconds,
                fps=generation.fps,
                seed=generation.seed,
                cfg_scale=generation.cfg_scale,
            )

            if result.error:
                generation.status = "failed"
                generation.error_message = result.error
                await db.commit()
                return {"error": result.error}

            generation.provider_job_id = result.provider_job_id
            generation.provider_model_id = result.metadata.get("model") if result.metadata else None
            await db.commit()

            video_url = await _poll_for_completion(provider, generation.provider_job_id, db, generation)

            if video_url:
                storage = StorageService()
                async with httpx.AsyncClient() as client:
                    video_resp = await client.get(video_url, timeout=120.0)
                    video_resp.raise_for_status()

                    key = f"videos/{generation.user_id}/{generation.id}.mp4"
                    public_url = await storage.upload_bytes(key, video_resp.content, "video/mp4")

                    generation.video_url = public_url
                    generation.video_key = key
                    generation.file_size_bytes = len(video_resp.content)

                generation.status = "completed"
                generation.progress = 100
                generation.completed_at = datetime.utcnow()
            else:
                generation.status = "failed"
                generation.error_message = "Generation timed out or failed"

            await db.commit()
            return {"status": generation.status, "video_url": generation.video_url}

        except Exception as e:
            generation.status = "failed"
            generation.error_message = str(e)
            await db.commit()
            return {"error": str(e)}
        finally:
            if provider and hasattr(provider, 'close'):
                await provider.close()
            await engine.dispose()


async def _poll_for_completion(provider, job_id: str, db, generation, max_attempts: int = 120, interval: int = 5):
    for attempt in range(max_attempts):
        status = await provider.get_status(job_id)

        generation.progress = status.get("progress", generation.progress)
        if status.get("status") == "failed":
            generation.error_message = status.get("error", "Unknown error")
            await db.commit()
            return None

        await db.commit()

        if status.get("status") == "completed" and status.get("video_url"):
            return status["video_url"]

        await asyncio.sleep(interval)

    return None
