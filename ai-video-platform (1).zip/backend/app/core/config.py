from functools import lru_cache
from typing import List, Optional

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # App
    APP_NAME: str = "AI Video Platform"
    DEBUG: bool = False
    ENVIRONMENT: str = "production"
    SECRET_KEY: str
    FRONTEND_URL: str = "http://localhost:3000"

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://avp:avp_secret@localhost:5432/aivideo"

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    CELERY_BROKER_URL: str = "redis://localhost:6379/0"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/0"

    # AI Providers
    REPLICATE_API_TOKEN: Optional[str] = None
    RUNWAY_API_KEY: Optional[str] = None
    HUGGINGFACE_API_TOKEN: Optional[str] = None
    DEFAULT_AI_PROVIDER: str = "huggingface"

    # Storage (S3-compatible)
    AWS_ACCESS_KEY_ID: Optional[str] = None
    AWS_SECRET_ACCESS_KEY: Optional[str] = None
    S3_BUCKET: Optional[str] = None
    S3_ENDPOINT: Optional[str] = None
    S3_REGION: str = "us-east-1"
    S3_PUBLIC_URL: Optional[str] = None

    # Business
    CREDITS_PER_GENERATION: int = 10
    DEFAULT_FREE_CREDITS: int = 50
    MAX_VIDEO_DURATION_SECONDS: int = 5
    MAX_PROMPT_LENGTH: int = 1000

    # Stripe
    STRIPE_SECRET_KEY: Optional[str] = None
    STRIPE_WEBHOOK_SECRET: Optional[str] = None
    STRIPE_PRICE_ID_CREDITS: Optional[str] = None

    # OAuth
    GOOGLE_CLIENT_ID: Optional[str] = None
    GOOGLE_CLIENT_SECRET: Optional[str] = None

    # Monitoring
    SENTRY_DSN: Optional[str] = None

    @property
    def allowed_origins(self) -> List[str]:
        origins = [self.FRONTEND_URL]
        if self.DEBUG:
            origins.extend(["http://localhost:3000", "http://127.0.0.1:3000"])
        return origins


@lru_cache()
def get_settings() -> Settings:
    return Settings()
