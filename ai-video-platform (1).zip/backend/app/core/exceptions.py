from fastapi import HTTPException, status


class APIException(HTTPException):
    def __init__(self, status_code: int, detail: str, error_code: str = None):
        super().__init__(status_code=status_code, detail=detail)
        self.error_code = error_code


class InsufficientCreditsException(APIException):
    def __init__(self):
        super().__init__(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail="Insufficient credits to perform this generation",
            error_code="INSUFFICIENT_CREDITS",
        )


class VideoNotFoundException(APIException):
    def __init__(self):
        super().__init__(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Video not found",
            error_code="VIDEO_NOT_FOUND",
        )


class InvalidProviderException(APIException):
    def __init__(self, provider: str):
        super().__init__(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"AI provider '{provider}' is not configured or available",
            error_code="INVALID_PROVIDER",
        )
