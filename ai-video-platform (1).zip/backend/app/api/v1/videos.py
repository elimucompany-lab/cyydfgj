from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, desc

from app.api.deps import get_db, get_current_user, get_optional_user
from app.core.config import get_settings
from app.core.exceptions import InsufficientCreditsException, VideoNotFoundException
from app.models.user import User
from app.models.video import VideoGeneration
from app.schemas.video import (
    VideoGenerationCreate,
    VideoGenerationResponse,
    VideoListParams,
    VideoListResponse,
)
from app.services.storage import StorageService
from app.services.credit_service import CreditService
from app.tasks.video_tasks import generate_video_task

router = APIRouter()
settings = get_settings()


@router.post("/generate", response_model=VideoGenerationResponse)
async def create_generation(
    prompt: Optional[str] = Form(None),
    negative_prompt: Optional[str] = Form(None),
    width: int = Form(512),
    height: int = Form(512),
    duration_seconds: int = Form(5),
    fps: int = Form(8),
    seed: Optional[int] = Form(None),
    cfg_scale: float = Form(7.0),
    provider: str = Form("replicate"),
    source_image: Optional[UploadFile] = File(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Validate prompt or image
    if not prompt and not source_image:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Either prompt or source_image is required",
        )

    # Check credits
    credit_service = CreditService(db)
    if current_user.credits < settings.CREDITS_PER_GENERATION:
        raise InsufficientCreditsException()

    # Handle image upload if provided
    source_image_url = None
    source_image_key = None
    if source_image:
        storage = StorageService()
        key = f"uploads/{current_user.id}/{source_image.filename}"
        content = await source_image.read()
        source_image_url = await storage.upload_bytes(key, content, source_image.content_type or "image/jpeg")
        source_image_key = key

    # Create generation record
    generation = VideoGeneration(
        user_id=current_user.id,
        prompt=prompt,
        negative_prompt=negative_prompt,
        source_image_url=source_image_url,
        source_image_key=source_image_key,
        width=width,
        height=height,
        duration_seconds=min(duration_seconds, settings.MAX_VIDEO_DURATION_SECONDS),
        fps=fps,
        seed=seed,
        cfg_scale=cfg_scale,
        provider=provider,
        status="pending",
        credits_used=settings.CREDITS_PER_GENERATION,
    )
    db.add(generation)
    await db.flush()

    # Deduct credits immediately
    await credit_service.deduct_credits(
        user_id=current_user.id,
        amount=settings.CREDITS_PER_GENERATION,
        video_generation_id=generation.id,
        description=f"Video generation #{generation.id}",
    )
    current_user.credits -= settings.CREDITS_PER_GENERATION
    current_user.total_generations += 1

    await db.commit()
    await db.refresh(generation)

    # Queue background task
    generate_video_task.delay(str(generation.id))

    return generation


@router.get("/list", response_model=VideoListResponse)
async def list_generations(
    params: VideoListParams = Depends(),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = select(VideoGeneration).where(VideoGeneration.user_id == current_user.id)
    count_query = select(func.count()).select_from(VideoGeneration).where(VideoGeneration.user_id == current_user.id)

    if params.status:
        query = query.where(VideoGeneration.status == params.status)
        count_query = count_query.where(VideoGeneration.status == params.status)

    query = query.order_by(desc(VideoGeneration.created_at))
    query = query.offset((params.page - 1) * params.limit).limit(params.limit)

    result = await db.execute(query)
    items = result.scalars().all()

    total_result = await db.execute(count_query)
    total = total_result.scalar()
    pages = (total + params.limit - 1) // params.limit

    return VideoListResponse(
        items=items,
        total=total,
        page=params.page,
        pages=pages,
    )


@router.get("/{video_id}", response_model=VideoGenerationResponse)
async def get_generation(
    video_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(VideoGeneration).where(
            VideoGeneration.id == video_id,
            VideoGeneration.user_id == current_user.id,
        )
    )
    generation = result.scalar_one_or_none()
    if not generation:
        raise VideoNotFoundException()
    return generation


@router.delete("/{video_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_generation(
    video_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(VideoGeneration).where(
            VideoGeneration.id == video_id,
            VideoGeneration.user_id == current_user.id,
        )
    )
    generation = result.scalar_one_or_none()
    if not generation:
        raise VideoNotFoundException()

    # Delete from storage
    if generation.video_key:
        storage = StorageService()
        await storage.delete(generation.video_key)
    if generation.source_image_key:
        storage = StorageService()
        await storage.delete(generation.source_image_key)

    await db.delete(generation)
    await db.commit()
    return None


@router.get("/public/{video_id}", response_model=VideoGenerationResponse)
async def get_public_generation(
    video_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: Optional[User] = Depends(get_optional_user),
):
    result = await db.execute(
        select(VideoGeneration).where(
            VideoGeneration.id == video_id,
            VideoGeneration.status == "completed",
        )
    )
    generation = result.scalar_one_or_none()
    if not generation:
        raise VideoNotFoundException()
    return generation
