from fastapi import APIRouter

from app.api.v1 import auth, videos, users, webhooks

router = APIRouter(prefix="/v1")

router.include_router(auth.router, prefix="/auth", tags=["Authentication"])
router.include_router(videos.router, prefix="/videos", tags=["Videos"])
router.include_router(users.router, prefix="/users", tags=["Users"])
router.include_router(webhooks.router, prefix="/webhooks", tags=["Webhooks"])
