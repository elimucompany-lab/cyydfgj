from fastapi import APIRouter, Request, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db
from app.core.config import get_settings
from app.services.webhook_handlers import WebhookHandler

router = APIRouter()
settings = get_settings()


@router.post("/stripe")
async def stripe_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    if not settings.STRIPE_WEBHOOK_SECRET:
        raise HTTPException(status_code=501, detail="Stripe not configured")

    handler = WebhookHandler(db)
    try:
        await handler.handle_stripe(payload, sig_header)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

    return {"status": "success"}
