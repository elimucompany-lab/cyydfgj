import uuid
from datetime import datetime
from enum import Enum as PyEnum

from sqlalchemy import Column, String, DateTime, Integer, ForeignKey, Text, Numeric, Index
from sqlalchemy.dialects.postgresql import UUID

from app.core.database import Base


class TransactionType(str, PyEnum):
    GRANT = "grant"
    PURCHASE = "purchase"
    USAGE = "usage"
    REFUND = "refund"
    BONUS = "bonus"


class CreditTransaction(Base):
    __tablename__ = "credit_transactions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    amount = Column(Integer, nullable=False)
    transaction_type = Column(String(20), nullable=False)

    # Reference
    video_generation_id = Column(UUID(as_uuid=True), ForeignKey("video_generations.id", ondelete="SET NULL"), nullable=True)
    stripe_payment_intent_id = Column(String(100), nullable=True)

    description = Column(Text, nullable=True)
    balance_after = Column(Integer, nullable=False)

    created_at = Column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)

    __table_args__ = (
        Index("ix_credit_transactions_user_created", "user_id", "created_at"),
    )
