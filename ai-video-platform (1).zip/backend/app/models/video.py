import uuid
from datetime import datetime

from sqlalchemy import Column, String, DateTime, Integer, ForeignKey, Text, Float, Index
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship

from app.core.database import Base


class VideoGeneration(Base):
    __tablename__ = "video_generations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    # Input
    prompt = Column(Text, nullable=True)
    negative_prompt = Column(Text, nullable=True)
    source_image_url = Column(String(500), nullable=True)
    source_image_key = Column(String(500), nullable=True)

    # Parameters
    width = Column(Integer, default=512, nullable=False)
    height = Column(Integer, default=512, nullable=False)
    duration_seconds = Column(Integer, default=5, nullable=False)
    fps = Column(Integer, default=8, nullable=False)
    seed = Column(Integer, nullable=True)
    cfg_scale = Column(Float, default=7.0, nullable=True)

    # Provider info
    provider = Column(String(50), nullable=False, default="replicate")
    provider_model_id = Column(String(200), nullable=True)
    provider_job_id = Column(String(200), nullable=True, index=True)

    # Status tracking
    status = Column(String(20), nullable=False, default="pending", index=True)
    # pending, processing, completed, failed, cancelled

    progress = Column(Integer, default=0, nullable=False)
    error_message = Column(Text, nullable=True)

    # Output
    video_url = Column(String(500), nullable=True)
    video_key = Column(String(500), nullable=True)
    thumbnail_url = Column(String(500), nullable=True)
    file_size_bytes = Column(Integer, nullable=True)
    metadata = Column(JSONB, default=dict, nullable=False)

    # Cost tracking
    credits_used = Column(Integer, default=0, nullable=False)

    created_at = Column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    started_at = Column(DateTime(timezone=True), nullable=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)

    user = relationship("User", backref="video_generations")

    __table_args__ = (
        Index("ix_video_generations_user_status", "user_id", "status"),
        Index("ix_video_generations_created_at", "created_at"),
    )
