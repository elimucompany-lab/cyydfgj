import stripe
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.config import get_settings
from app.models.user import User
from app.services.credit_service import CreditService

settings = get_settings()


class WebhookHandler:
    def __init__(self, db: AsyncSession):
        self.db = db
        if settings.STRIPE_SECRET_KEY:
            stripe.api_key = settings.STRIPE_SECRET_KEY

    async def handle_stripe(self, payload: bytes, sig_header: str) -> None:
        if not settings.STRIPE_WEBHOOK_SECRET:
            raise ValueError("Stripe webhook secret not configured")

        event = stripe.Webhook.construct_event(payload, sig_header, settings.STRIPE_WEBHOOK_SECRET)

        if event["type"] == "payment_intent.succeeded":
            payment_intent = event["data"]["object"]
            await self._handle_payment_success(payment_intent)
        elif event["type"] == "payment_intent.payment_failed":
            payment_intent = event["data"]["object"]
            await self._handle_payment_failure(payment_intent)

    async def _handle_payment_success(self, payment_intent: dict) -> None:
        metadata = payment_intent.get("metadata", {})
        user_id = metadata.get("user_id")
        credits = int(metadata.get("credits", 0))

        if not user_id or credits <= 0:
            return

        from uuid import UUID
        result = await self.db.execute(select(User).where(User.id == UUID(user_id)))
        user = result.scalar_one_or_none()
        if not user:
            return

        credit_service = CreditService(self.db)
        await credit_service.add_credits(
            user_id=user.id,
            amount=credits,
            transaction_type="purchase",
            description=f"Stripe purchase: {payment_intent['id']}",
            stripe_payment_intent_id=payment_intent["id"],
        )
        await self.db.commit()

    async def _handle_payment_failure(self, payment_intent: dict) -> None:
        pass
