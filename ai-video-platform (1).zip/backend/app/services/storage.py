import asyncio
from typing import Optional

import boto3
from botocore.config import Config as BotoConfig

from app.core.config import get_settings

settings = get_settings()


class StorageService:
    def __init__(self):
        self._client = None
        self._bucket = settings.S3_BUCKET
        self._public_url = settings.S3_PUBLIC_URL

    def _get_client(self):
        if self._client is None:
            session = boto3.session.Session()
            config = BotoConfig(
                retries={"max_attempts": 3, "mode": "standard"},
                connect_timeout=10,
                read_timeout=30,
            )
            self._client = session.client(
                "s3",
                region_name=settings.S3_REGION,
                endpoint_url=settings.S3_ENDPOINT,
                aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
                config=config,
            )
        return self._client

    async def upload_bytes(self, key: str, data: bytes, content_type: str = "application/octet-stream") -> str:
        loop = asyncio.get_event_loop()
        client = self._get_client()

        await loop.run_in_executor(
            None,
            lambda: client.put_object(
                Bucket=self._bucket,
                Key=key,
                Body=data,
                ContentType=content_type,
                ACL="public-read",
            ),
        )

        if self._public_url:
            return f"{self._public_url}/{key}"
        return f"{settings.S3_ENDPOINT}/{self._bucket}/{key}"

    async def upload_file(self, key: str, file_path: str, content_type: str = "application/octet-stream") -> str:
        loop = asyncio.get_event_loop()
        client = self._get_client()

        await loop.run_in_executor(
            None,
            lambda: client.upload_file(
                file_path,
                self._bucket,
                key,
                ExtraArgs={"ContentType": content_type, "ACL": "public-read"},
            ),
        )

        if self._public_url:
            return f"{self._public_url}/{key}"
        return f"{settings.S3_ENDPOINT}/{self._bucket}/{key}"

    async def delete(self, key: str) -> None:
        loop = asyncio.get_event_loop()
        client = self._get_client()

        await loop.run_in_executor(
            None,
            lambda: client.delete_object(Bucket=self._bucket, Key=key),
        )

    async def generate_presigned_url(self, key: str, expiration: int = 3600) -> str:
        loop = asyncio.get_event_loop()
        client = self._get_client()

        return await loop.run_in_executor(
            None,
            lambda: client.generate_presigned_url(
                "get_object",
                Params={"Bucket": self._bucket, "Key": key},
                ExpiresIn=expiration,
            ),
        )
