from datetime import datetime
from typing import Optional
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.models.credit import CreditTransaction
from app.models.user import User


class CreditService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_balance(self, user_id: UUID) -> int:
        result = await self.db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        return user.credits if user else 0

    async def add_credits(
        self,
        user_id: UUID,
        amount: int,
        transaction_type: str,
        description: Optional[str] = None,
        stripe_payment_intent_id: Optional[str] = None,
    ) -> CreditTransaction:
        result = await self.db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        if not user:
            raise ValueError("User not found")

        new_balance = user.credits + amount
        user.credits = new_balance

        transaction = CreditTransaction(
            user_id=user_id,
            amount=amount,
            transaction_type=transaction_type,
            description=description,
            stripe_payment_intent_id=stripe_payment_intent_id,
            balance_after=new_balance,
        )
        self.db.add(transaction)
        await self.db.flush()
        return transaction

    async def deduct_credits(
        self,
        user_id: UUID,
        amount: int,
        video_generation_id: Optional[UUID] = None,
        description: Optional[str] = None,
    ) -> CreditTransaction:
        result = await self.db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        if not user:
            raise ValueError("User not found")

        if user.credits < amount:
            raise ValueError("Insufficient credits")

        new_balance = user.credits - amount
        user.credits = new_balance

        transaction = CreditTransaction(
            user_id=user_id,
            amount=-amount,
            transaction_type="usage",
            video_generation_id=video_generation_id,
            description=description,
            balance_after=new_balance,
        )
        self.db.add(transaction)
        await self.db.flush()
        return transaction
