import asyncio
from typing import Optional, Dict, Any
import httpx

from app.core.config import get_settings
from app.services.ai_providers.base import BaseVideoProvider, GenerationResult

settings = get_settings()

RUNWAY_API_BASE = "https://api.runwayml.com/v1"


class RunwayProvider(BaseVideoProvider):
    def __init__(self):
        self.api_key = settings.RUNWAY_API_KEY
        if not self.api_key:
            raise ValueError("RUNWAY_API_KEY not configured")
        self.client = httpx.AsyncClient(
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(60.0, connect=10.0),
        )

    @property
    def name(self) -> str:
        return "runway"

    @property
    def supported_dimensions(self) -> list[tuple[int, int]]:
        return [(1080, 1920), (720, 1280), (512, 512)]

    async def generate(
        self,
        prompt: Optional[str],
        negative_prompt: Optional[str] = None,
        source_image_url: Optional[str] = None,
        width: int = 512,
        height: int = 512,
        duration_seconds: int = 5,
        fps: int = 8,
        seed: Optional[int] = None,
        cfg_scale: Optional[float] = None,
    ) -> GenerationResult:
        payload = {
            "prompt": prompt or "",
            "width": width,
            "height": height,
            "duration": min(duration_seconds, 5),
            "ratio": "16:9" if width > height else "9:16" if height > width else "1:1",
        }

        if seed is not None:
            payload["seed"] = seed
        if source_image_url:
            payload["image_url"] = source_image_url

        try:
            resp = await self.client.post(
                f"{RUNWAY_API_BASE}/generations",
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()

            return GenerationResult(
                provider_job_id=data.get("id"),
                metadata={
                    "model": data.get("model", "gen3"),
                    "status": data.get("status"),
                },
            )
        except httpx.HTTPStatusError as e:
            return GenerationResult(
                error=f"Runway API error: {e.response.status_code} - {e.response.text}",
            )
        except Exception as e:
            return GenerationResult(error=f"Runway error: {str(e)}")

    async def get_status(self, job_id: str) -> Dict[str, Any]:
        try:
            resp = await self.client.get(f"{RUNWAY_API_BASE}/generations/{job_id}")
            resp.raise_for_status()
            data = resp.json()

            status_map = {
                "PENDING": "pending",
                "RUNNING": "processing",
                "SUCCEEDED": "completed",
                "FAILED": "failed",
                "CANCELLED": "cancelled",
            }

            result = {
                "status": status_map.get(data.get("status"), "processing"),
                "progress": 50 if data.get("status") == "RUNNING" else 100 if data.get("status") == "SUCCEEDED" else 0,
                "output": data.get("output"),
                "error": data.get("error"),
            }

            if data.get("output"):
                if isinstance(data["output"], list) and len(data["output"]) > 0:
                    result["video_url"] = data["output"][0].get("url")
                elif isinstance(data["output"], dict):
                    result["video_url"] = data["output"].get("url")

            return result
        except Exception as e:
            return {"status": "failed", "error": str(e), "progress": 0}

    async def cancel(self, job_id: str) -> bool:
        try:
            resp = await self.client.delete(f"{RUNWAY_API_BASE}/generations/{job_id}")
            return resp.status_code in (200, 202, 204)
        except Exception:
            return False

    async def close(self):
        await self.client.aclose()
