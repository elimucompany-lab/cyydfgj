import asyncio
from typing import Optional, Dict, Any
import httpx

from app.core.config import get_settings
from app.services.ai_providers.base import BaseVideoProvider, GenerationResult

settings = get_settings()

REPLICATE_API_BASE = "https://api.replicate.com/v1"

# Model mapping - update with latest available models
REPLICATE_MODELS = {
    "text-to-video": "stability-ai/stable-video-diffusion",
    "image-to-video": "stability-ai/stable-video-diffusion",
    "fast": "anotherjesse/zeroscope-v2-xl",
}


class ReplicateProvider(BaseVideoProvider):
    def __init__(self):
        self.api_token = settings.REPLICATE_API_TOKEN
        if not self.api_token:
            raise ValueError("REPLICATE_API_TOKEN not configured")
        self.client = httpx.AsyncClient(
            headers={
                "Authorization": f"Token {self.api_token}",
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(60.0, connect=10.0),
        )

    @property
    def name(self) -> str:
        return "replicate"

    @property
    def supported_dimensions(self) -> list[tuple[int, int]]:
        return [(512, 512), (576, 1024), (768, 768), (1024, 576)]

    async def generate(
        self,
        prompt: Optional[str],
        negative_prompt: Optional[str] = None,
        source_image_url: Optional[str] = None,
        width: int = 512,
        height: int = 512,
        duration_seconds: int = 5,
        fps: int = 8,
        seed: Optional[int] = None,
        cfg_scale: Optional[float] = None,
    ) -> GenerationResult:
        model = REPLICATE_MODELS["image-to-video"] if source_image_url else REPLICATE_MODELS["text-to-video"]

        input_data = {
            "width": width,
            "height": height,
            "num_frames": min(duration_seconds * fps, 24),
            "fps": fps,
        }

        if seed is not None:
            input_data["seed"] = seed
        if cfg_scale is not None:
            input_data["motion_bucket_id"] = int(cfg_scale * 10)
        if source_image_url:
            input_data["image"] = source_image_url
        if prompt:
            input_data["prompt"] = prompt
        if negative_prompt:
            input_data["negative_prompt"] = negative_prompt

        try:
            resp = await self.client.post(
                f"{REPLICATE_API_BASE}/models/{model}/predictions",
                json={"input": input_data},
            )
            resp.raise_for_status()
            data = resp.json()

            return GenerationResult(
                provider_job_id=data.get("id"),
                metadata={
                    "model": model,
                    "version": data.get("version"),
                    "urls": data.get("urls"),
                },
            )
        except httpx.HTTPStatusError as e:
            return GenerationResult(
                error=f"Replicate API error: {e.response.status_code} - {e.response.text}",
            )
        except Exception as e:
            return GenerationResult(error=f"Replicate error: {str(e)}")

    async def get_status(self, job_id: str) -> Dict[str, Any]:
        try:
            resp = await self.client.get(f"{REPLICATE_API_BASE}/predictions/{job_id}")
            resp.raise_for_status()
            data = resp.json()

            status_map = {
                "starting": "processing",
                "processing": "processing",
                "succeeded": "completed",
                "failed": "failed",
                "canceled": "cancelled",
            }

            result = {
                "status": status_map.get(data.get("status"), "processing"),
                "progress": 0,
                "output": data.get("output"),
                "error": data.get("error"),
            }

            if data.get("output") and isinstance(data["output"], str):
                result["video_url"] = data["output"]
            elif data.get("output") and isinstance(data["output"], list) and len(data["output"]) > 0:
                result["video_url"] = data["output"][0]

            logs = data.get("logs", "")
            if logs:
                import re
                progress_match = re.search(r'(\\d+)%', logs)
                if progress_match:
                    result["progress"] = int(progress_match.group(1))

            return result
        except Exception as e:
            return {"status": "failed", "error": str(e), "progress": 0}

    async def cancel(self, job_id: str) -> bool:
        try:
            resp = await self.client.post(f"{REPLICATE_API_BASE}/predictions/{job_id}/cancel")
            return resp.status_code == 200
        except Exception:
            return False

    async def close(self):
        await self.client.aclose()
