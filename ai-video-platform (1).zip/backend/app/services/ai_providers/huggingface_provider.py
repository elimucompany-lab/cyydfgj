"""
Hugging Face Inference Provider integration.
Uses HF's unified API to route to multiple inference backends.
Free tier: $0.10/month credits for all users.
"""

import asyncio
from typing import Optional, Dict, Any
import httpx

from app.core.config import get_settings
from app.services.ai_providers.base import BaseVideoProvider, GenerationResult

settings = get_settings()

HF_API_BASE = "https://api-inference.huggingface.co"
HF_INFERENCE_V2 = "https://router.huggingface.co"

# Video generation models available via HF Inference Providers
HF_VIDEO_MODELS = {
    "text-to-video": "stabilityai/stable-video-diffusion-img2vid-xt",
    "image-to-video": "stabilityai/stable-video-diffusion-img2vid-xt",
}


class HuggingFaceProvider(BaseVideoProvider):
    """
    Hugging Face Inference Provider for video generation.

    Uses HF's InferenceClient pattern with their v2 router API.
    Supports both direct HF Hub inference and routed provider requests.

    Billing: Uses HF's monthly credits ($0.10 free tier). No separate
    API keys needed for individual providers when using HF routing.
    """

    def __init__(self):
        self.api_token = settings.HUGGINGFACE_API_TOKEN
        if not self.api_token:
            raise ValueError(
                "HUGGINGFACE_API_TOKEN not configured. "
                "Get one free at https://huggingface.co/settings/tokens"
            )

        self.client = httpx.AsyncClient(
            headers={
                "Authorization": f"Bearer {self.api_token}",
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(300.0, connect=30.0),
            follow_redirects=True,
        )

        # Use Inference Providers v2 for better reliability
        self.use_router = True

    @property
    def name(self) -> str:
        return "huggingface"

    @property
    def supported_dimensions(self) -> list[tuple[int, int]]:
        return [(512, 512), (576, 1024), (1024, 576), (768, 768)]

    async def generate(
        self,
        prompt: Optional[str],
        negative_prompt: Optional[str] = None,
        source_image_url: Optional[str] = None,
        width: int = 512,
        height: int = 512,
        duration_seconds: int = 5,
        fps: int = 8,
        seed: Optional[int] = None,
        cfg_scale: Optional[float] = None,
    ) -> GenerationResult:
        """
        Generate video via Hugging Face Inference API.

        For video models, we use the async job pattern:
        1. Submit request to model endpoint
        2. Poll for completion (HF returns 503 while loading, then result)
        """
        model = HF_VIDEO_MODELS["image-to-video"] if source_image_url else HF_VIDEO_MODELS["text-to-video"]

        # Build payload
        payload: Dict[str, Any] = {
            "inputs": prompt or "",
            "parameters": {
                "width": width,
                "height": height,
                "num_frames": min(duration_seconds * fps, 25),
                "fps": fps,
            }
        }

        if seed is not None:
            payload["parameters"]["seed"] = seed
        if negative_prompt:
            payload["parameters"]["negative_prompt"] = negative_prompt

        # For image-to-video, download and send image bytes
        if source_image_url:
            try:
                async with httpx.AsyncClient() as temp_client:
                    img_resp = await temp_client.get(source_image_url, timeout=30.0)
                    img_resp.raise_for_status()
                    # HF expects raw bytes for image input
                    payload = img_resp.content
                    # Update headers for binary payload
                    headers = {
                        "Authorization": f"Bearer {self.api_token}",
                        "Content-Type": "image/jpeg",
                    }
            except Exception as e:
                return GenerationResult(error=f"Failed to fetch source image: {e}")

        try:
            # Submit to HF Inference API
            # Video models on HF often use the pipeline endpoint
            endpoint = f"{HF_API_BASE}/models/{model}"

            resp = await self.client.post(
                endpoint,
                json=payload if isinstance(payload, dict) else None,
                content=payload if isinstance(payload, bytes) else None,
                headers=headers if source_image_url else None,
            )

            # Handle model loading (503 with estimated_time)
            if resp.status_code == 503:
                data = resp.json()
                estimated_time = data.get("estimated_time", 30)

                # Return a job-like structure for polling
                return GenerationResult(
                    provider_job_id=f"hf:{model}:{asyncio.get_event_loop().time()}",
                    metadata={
                        "model": model,
                        "estimated_time": estimated_time,
                        "endpoint": endpoint,
                        "payload_type": "image" if source_image_url else "text",
                        "payload": payload if isinstance(payload, dict) else None,
                    },
                )

            resp.raise_for_status()

            # Direct response (model already loaded)
            result_data = resp.content  # Binary video data

            return GenerationResult(
                video_bytes=result_data,
                provider_job_id=f"hf-direct:{asyncio.get_event_loop().time()}",
                metadata={"model": model, "size": len(result_data)},
            )

        except httpx.HTTPStatusError as e:
            return GenerationResult(
                error=f"HF API error: {e.response.status_code} - {e.response.text[:200]}",
            )
        except Exception as e:
            return GenerationResult(error=f"HF error: {str(e)}")

    async def get_status(self, job_id: str) -> Dict[str, Any]:
        """
        Poll HF model status.

        HF doesn't have traditional job IDs. We store the endpoint and
        retry until the model loads and returns data.
        """
        if not job_id.startswith("hf:"):
            return {"status": "failed", "error": "Invalid job ID", "progress": 0}

        parts = job_id.split(":")
        model = parts[1] if len(parts) > 1 else HF_VIDEO_MODELS["text-to-video"]
        endpoint = f"{HF_API_BASE}/models/{model}"

        try:
            resp = await self.client.post(
                endpoint,
                json={"inputs": "test", "parameters": {"num_frames": 1}},
            )

            if resp.status_code == 503:
                data = resp.json()
                estimated = data.get("estimated_time", 30)
                # Rough progress estimate based on typical 120s load time
                progress = min(95, int((1 - min(estimated, 120) / 120) * 100))
                return {
                    "status": "processing",
                    "progress": progress,
                    "estimated_time": estimated,
                }

            resp.raise_for_status()

            # Model is ready - return completed
            return {
                "status": "completed",
                "progress": 100,
                "video_url": None,  # We need to re-run the actual generation
                "ready": True,
            }

        except Exception as e:
            return {"status": "failed", "error": str(e), "progress": 0}

    async def cancel(self, job_id: str) -> bool:
        """HF doesn't support cancellation - models run until complete."""
        return False

    async def close(self):
        await self.client.aclose()
