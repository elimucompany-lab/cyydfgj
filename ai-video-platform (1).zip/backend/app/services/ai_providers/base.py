from abc import ABC, abstractmethod
from typing import Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class GenerationResult:
    video_url: Optional[str] = None
    video_bytes: Optional[bytes] = None
    provider_job_id: Optional[str] = None
    metadata: Dict[str, Any] = None
    error: Optional[str] = None


class BaseVideoProvider(ABC):
    @abstractmethod
    async def generate(
        self,
        prompt: Optional[str],
        negative_prompt: Optional[str] = None,
        source_image_url: Optional[str] = None,
        width: int = 512,
        height: int = 512,
        duration_seconds: int = 5,
        fps: int = 8,
        seed: Optional[int] = None,
        cfg_scale: Optional[float] = None,
    ) -> GenerationResult:
        pass

    @abstractmethod
    async def get_status(self, job_id: str) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def cancel(self, job_id: str) -> bool:
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        pass

    @property
    @abstractmethod
    def supported_dimensions(self) -> list[tuple[int, int]]:
        pass
