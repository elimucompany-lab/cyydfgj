from app.services.ai_providers.base import BaseVideoProvider, GenerationResult
from app.services.ai_providers.replicate_provider import ReplicateProvider
from app.services.ai_providers.runway_provider import RunwayProvider
from app.services.ai_providers.huggingface_provider import HuggingFaceProvider

PROVIDERS = {
    "replicate": ReplicateProvider,
    "runway": RunwayProvider,
    "huggingface": HuggingFaceProvider,
}

def get_provider(name: str) -> BaseVideoProvider:
    if name not in PROVIDERS:
        raise ValueError(f"Unknown provider: {name}. Available: {list(PROVIDERS.keys())}")
    return PROVIDERS[name]()

__all__ = ["BaseVideoProvider", "GenerationResult", "ReplicateProvider", "RunwayProvider", "HuggingFaceProvider", "get_provider", "PROVIDERS"]
