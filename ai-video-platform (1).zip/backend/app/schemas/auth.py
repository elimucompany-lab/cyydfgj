from datetime import datetime
from typing import Optional

from pydantic import BaseModel, EmailStr


class TokenPayload(BaseModel):
    sub: Optional[str] = None
    exp: Optional[datetime] = None


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int


class OAuthCallback(BaseModel):
    code: str
    state: Optional[str] = None
    redirect_uri: str


class GoogleUserInfo(BaseModel):
    id: str
    email: EmailStr
    name: Optional[str] = None
    picture: Optional[str] = None
    verified_email: bool = False
