from datetime import datetime
from typing import Optional, Dict, Any
from uuid import UUID

from pydantic import BaseModel, Field, field_validator


class VideoGenerationCreate(BaseModel):
    prompt: Optional[str] = Field(None, max_length=1000)
    negative_prompt: Optional[str] = Field(None, max_length=500)
    source_image_url: Optional[str] = None
    width: int = Field(default=512, ge=256, le=2048)
    height: int = Field(default=512, ge=256, le=2048)
    duration_seconds: int = Field(default=5, ge=1, le=10)
    fps: int = Field(default=8, ge=1, le=30)
    seed: Optional[int] = None
    cfg_scale: Optional[float] = Field(default=7.0, ge=1.0, le=20.0)
    provider: str = Field(default="replicate")

    @field_validator("provider")
    @classmethod
    def validate_provider(cls, v: str) -> str:
        allowed = {"replicate", "runway", "custom"}
        if v not in allowed:
            raise ValueError(f"Provider must be one of {allowed}")
        return v


class VideoGenerationUpdate(BaseModel):
    status: Optional[str] = None
    progress: Optional[int] = Field(None, ge=0, le=100)
    video_url: Optional[str] = None
    video_key: Optional[str] = None
    thumbnail_url: Optional[str] = None
    error_message: Optional[str] = None
    provider_job_id: Optional[str] = None
    file_size_bytes: Optional[int] = None
    metadata: Optional[Dict[str, Any]] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


class VideoGenerationInDB(BaseModel):
    id: UUID
    user_id: UUID
    prompt: Optional[str] = None
    negative_prompt: Optional[str] = None
    source_image_url: Optional[str] = None
    width: int
    height: int
    duration_seconds: int
    fps: int
    seed: Optional[int] = None
    cfg_scale: Optional[float] = None
    provider: str
    provider_model_id: Optional[str] = None
    provider_job_id: Optional[str] = None
    status: str
    progress: int
    error_message: Optional[str] = None
    video_url: Optional[str] = None
    video_key: Optional[str] = None
    thumbnail_url: Optional[str] = None
    file_size_bytes: Optional[int] = None
    metadata: Dict[str, Any]
    credits_used: int
    created_at: datetime
    updated_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class VideoGenerationResponse(VideoGenerationInDB):
    pass


class VideoListParams(BaseModel):
    page: int = Field(default=1, ge=1)
    limit: int = Field(default=20, ge=1, le=100)
    status: Optional[str] = None


class VideoListResponse(BaseModel):
    items: list[VideoGenerationResponse]
    total: int
    page: int
    pages: int
