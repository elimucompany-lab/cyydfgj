export interface User {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  is_active: boolean;
  is_admin: boolean;
  credits: number;
  total_generations: number;
  created_at: string;
  updated_at: string;
  last_login_at: string | null;
}

export interface VideoGeneration {
  id: string;
  user_id: string;
  prompt: string | null;
  negative_prompt: string | null;
  source_image_url: string | null;
  width: number;
  height: number;
  duration_seconds: number;
  fps: number;
  seed: number | null;
  cfg_scale: number | null;
  provider: string;
  provider_model_id: string | null;
  provider_job_id: string | null;
  status: "pending" | "processing" | "completed" | "failed" | "cancelled";
  progress: number;
  error_message: string | null;
  video_url: string | null;
  video_key: string | null;
  thumbnail_url: string | null;
  file_size_bytes: number | null;
  metadata: Record<string, unknown>;
  credits_used: number;
  created_at: string;
  updated_at: string;
  started_at: string | null;
  completed_at: string | null;
}

export interface GenerationParams {
  prompt?: string;
  negative_prompt?: string;
  source_image?: File | null;
  width: number;
  height: number;
  duration_seconds: number;
  fps: number;
  seed?: number;
  cfg_scale: number;
  provider: string;
}
