import axios from "axios";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export const api = axios.create({
  baseURL: `${API_BASE}/api/v1`,
  headers: {
    "Content-Type": "application/json",
  },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("access_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem("access_token");
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);

export const authApi = {
  login: (email: string, password: string) => {
    const credentials = btoa(`${email}:${password}`);
    return api.post("/auth/login", {}, {
      headers: { Authorization: `Basic ${credentials}` },
    });
  },
  register: (email: string, password: string, fullName?: string) =>
    api.post("/auth/register", { email, password, full_name: fullName }),
  google: (code: string, redirectUri: string) =>
    api.post("/auth/google", { code, redirect_uri: redirectUri }),
  me: () => api.get("/auth/me"),
};

export const videoApi = {
  generate: (data: FormData) => api.post("/videos/generate", data),
  list: (params?: { page?: number; limit?: number; status?: string }) =>
    api.get("/videos/list", { params }),
  get: (id: string) => api.get(`/videos/${id}`),
  delete: (id: string) => api.delete(`/videos/${id}`),
};

export const userApi = {
  profile: () => api.get("/users/profile"),
};
