"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import toast from "react-hot-toast";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useGenerations } from "@/hooks/use-generations";
import { formatDate, formatBytes } from "@/lib/utils";
import {
  Play, Trash2, Download, RefreshCw, Loader2,
  Image as ImageIcon, AlertCircle, Wand2
} from "lucide-react";

const statusVariants: Record<string, "pending" | "processing" | "completed" | "failed"> = {
  pending: "pending",
  processing: "processing",
  completed: "completed",
  failed: "failed",
  cancelled: "failed",
};

export function VideoGallery() {
  const { generations, isLoading, error, hasMore, refresh, loadMore, deleteGeneration } = useGenerations();
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const hasProcessing = generations.some((g) => g.status === "pending" || g.status === "processing");
      if (hasProcessing) refresh();
    }, 5000);
    return () => clearInterval(interval);
  }, [generations, refresh]);

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      await deleteGeneration(id);
      toast.success("Video deleted");
    } catch {
      toast.error("Failed to delete video");
    } finally {
      setDeletingId(null);
    }
  };

  if (isLoading && generations.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error && generations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <AlertCircle className="h-8 w-8 text-destructive" />
        <p className="text-muted-foreground">{error}</p>
        <Button onClick={refresh} variant="outline">
          <RefreshCw className="h-4 w-4 mr-2" />
          Retry
        </Button>
      </div>
    );
  }

  if (generations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <ImageIcon className="h-12 w-12 text-muted-foreground" />
        <p className="text-muted-foreground">No videos yet. Create your first one!</p>
        <Link href="/generate">
          <Button>
            <Wand2 className="h-4 w-4 mr-2" />
            Generate Video
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {generations.length} video{generations.length !== 1 ? "s" : ""}
        </p>
        <Button onClick={refresh} variant="outline" size="sm">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {generations.map((gen, i) => (
          <motion.div
            key={gen.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <Card className="overflow-hidden group">
              <div className="aspect-video bg-secondary relative">
                {gen.status === "completed" && gen.video_url ? (
                  <video
                    src={gen.video_url}
                    className="w-full h-full object-cover"
                    controls
                    preload="metadata"
                  />
                ) : gen.source_image_url ? (
                  <img
                    src={gen.source_image_url}
                    alt="Source"
                    className="w-full h-full object-cover opacity-60"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <ImageIcon className="h-12 w-12 text-muted-foreground" />
                  </div>
                )}

                <div className="absolute top-2 right-2">
                  <Badge variant={statusVariants[gen.status] || "default"}>
                    {gen.status}
                  </Badge>
                </div>

                {gen.status === "processing" && (
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-secondary">
                    <div
                      className="h-full bg-primary transition-all duration-500"
                      style={{ width: `${gen.progress}%` }}
                    />
                  </div>
                )}
              </div>

              <CardContent className="p-4">
                <p className="text-sm font-medium line-clamp-2 mb-1">
                  {gen.prompt || "Image-to-video generation"}
                </p>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{formatDate(gen.created_at)}</span>
                  <span>{gen.provider}</span>
                </div>

                {gen.status === "completed" && (
                  <div className="flex items-center gap-2 mt-3">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 gap-1"
                      asChild
                    >
                      <a href={gen.video_url || "#"} download target="_blank" rel="noopener noreferrer">
                        <Download className="h-3.5 w-3.5" />
                        Download
                      </a>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      onClick={() => handleDelete(gen.id)}
                      disabled={deletingId === gen.id}
                    >
                      {deletingId === gen.id ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Trash2 className="h-3.5 w-3.5" />
                      )}
                    </Button>
                  </div>
                )}

                {gen.status === "failed" && gen.error_message && (
                  <p className="text-xs text-destructive mt-2 line-clamp-2">
                    {gen.error_message}
                  </p>
                )}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {hasMore && (
        <div className="flex justify-center">
          <Button onClick={loadMore} variant="outline" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                Loading...
              </>
            ) : (
              "Load More"
            )}
          </Button>
        </div>
      )}
    </div>
  );
}
