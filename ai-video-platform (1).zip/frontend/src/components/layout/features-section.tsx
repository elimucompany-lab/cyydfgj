"use client";

import { motion } from "framer-motion";
import { Image, Type, Settings, Download, Clock, Palette } from "lucide-react";

const features = [
  {
    icon: Type,
    title: "Text to Video",
    description: "Describe any scene and watch it come to life. Supports detailed prompts up to 1000 characters.",
  },
  {
    icon: Image,
    title: "Image to Video",
    description: "Upload a static image and animate it into a fluid, dynamic video with motion and depth.",
  },
  {
    icon: Settings,
    title: "Fine Control",
    description: "Adjust duration, FPS, dimensions, seed, and CFG scale for precise creative control.",
  },
  {
    icon: Palette,
    title: "Multiple Providers",
    description: "Switch between Replicate, Runway, and custom self-hosted models seamlessly.",
  },
  {
    icon: Clock,
    title: "Background Processing",
    description: "Jobs run asynchronously. Get notified when your video is ready. No waiting required.",
  },
  {
    icon: Download,
    title: "Easy Export",
    description: "Download your videos in MP4 format or share them with a public link instantly.",
  },
];

export function FeaturesSection() {
  return (
    <section className="py-20 bg-secondary/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight mb-4">Everything you need</h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            A complete toolkit for AI video generation, from prompt to polished output.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-6 rounded-xl border bg-card hover:shadow-md transition-shadow"
            >
              <feature.icon className="h-8 w-8 text-primary mb-4" />
              <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
