"use client";

import Link from "next/link";
import { useUserStore } from "@/store/user-store";
import { Button } from "@/components/ui/button";
import { Wand2, GalleryHorizontal, User, LogOut, Coins } from "lucide-react";

export function Navbar() {
  const { user, logout } = useUserStore();

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-14 items-center px-4">
        <Link href="/" className="flex items-center gap-2 font-bold text-lg mr-6">
          <Wand2 className="h-5 w-5" />
          <span>AI Video</span>
        </Link>

        <nav className="flex flex-1 items-center gap-6 text-sm">
          <Link href="/generate" className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors">
            <Wand2 className="h-4 w-4" />
            Generate
          </Link>
          <Link href="/gallery" className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors">
            <GalleryHorizontal className="h-4 w-4" />
            Gallery
          </Link>
        </nav>

        <div className="flex items-center gap-4">
          {user ? (
            <>
              <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                <Coins className="h-4 w-4 text-yellow-500" />
                <span>{user.credits} credits</span>
              </div>
              <div className="flex items-center gap-2">
                {user.avatar_url ? (
                  <img src={user.avatar_url} alt={user.full_name || ""} className="h-8 w-8 rounded-full" />
                ) : (
                  <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center">
                    <User className="h-4 w-4" />
                  </div>
                )}
                <span className="text-sm font-medium hidden sm:inline">{user.full_name || user.email}</span>
              </div>
              <Button variant="ghost" size="icon" onClick={logout}>
                <LogOut className="h-4 w-4" />
              </Button>
            </>
          ) : (
            <>
              <Link href="/login">
                <Button variant="ghost" size="sm">Sign In</Button>
              </Link>
              <Link href="/register">
                <Button size="sm">Get Started</Button>
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
