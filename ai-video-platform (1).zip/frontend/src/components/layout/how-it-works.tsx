"use client";

import { motion } from "framer-motion";
import { Pencil, Cpu, Film } from "lucide-react";

const steps = [
  {
    icon: Pencil,
    title: "1. Describe or Upload",
    description: "Write a detailed prompt or upload an image you want to animate.",
  },
  {
    icon: Cpu,
    title: "2. Configure & Generate",
    description: "Pick your AI provider, adjust settings, and start the generation.",
  },
  {
    icon: Film,
    title: "3. Download & Share",
    description: "Get your MP4 video, download it, or share the link with anyone.",
  },
];

export function HowItWorks() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight mb-4">How it works</h2>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Three simple steps from idea to video.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {steps.map((step, i) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.2 }}
              className="flex flex-col items-center text-center"
            >
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <step.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-lg mb-2">{step.title}</h3>
              <p className="text-sm text-muted-foreground">{step.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
