"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Wand2, Zap, Shield, Sparkles } from "lucide-react";

export function HeroSection() {
  return (
    <section className="relative overflow-hidden py-20 lg:py-32">
      <div className="container mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mx-auto max-w-3xl"
        >
          <div className="inline-flex items-center gap-2 rounded-full border bg-secondary px-3 py-1 text-sm mb-6">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Powered by state-of-the-art AI models</span>
          </div>
          <h1 className="text-4xl font-bold tracking-tight sm:text-6xl mb-6">
            Create stunning videos with{" "}
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              AI magic
            </span>
          </h1>
          <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto">
            Transform text prompts and images into high-quality videos using Replicate, Runway, and custom models. 
            No coding required.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/generate">
              <Button size="lg" className="gap-2">
                <Wand2 className="h-5 w-5" />
                Start Generating
              </Button>
            </Link>
            <Link href="/gallery">
              <Button size="lg" variant="outline">
                View Gallery
              </Button>
            </Link>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mt-16 grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-3xl mx-auto"
        >
          {[
            { icon: Zap, title: "Lightning Fast", desc: "Generate videos in minutes, not hours" },
            { icon: Shield, title: "Secure Storage", desc: "Your videos stored safely in the cloud" },
            { icon: Sparkles, title: "Multiple Models", desc: "Choose from top AI providers" },
          ].map((feature) => (
            <div key={feature.title} className="flex flex-col items-center gap-2 p-4 rounded-lg border bg-card">
              <feature.icon className="h-6 w-6 text-primary" />
              <h3 className="font-semibold">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.desc}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
