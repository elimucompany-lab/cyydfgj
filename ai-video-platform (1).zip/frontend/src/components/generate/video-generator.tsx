"use client";

import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import toast from "react-hot-toast";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent } from "@/components/ui/card";
import { videoApi } from "@/lib/api";
import { useUserStore } from "@/store/user-store";
import { useRouter } from "next/navigation";
import {
  Wand2, Upload, X, Image as ImageIcon, Loader2,
  Clock, Settings2, AlertCircle, ChevronDown, ChevronUp
} from "lucide-react";

const PROVIDERS = [
  { value: "huggingface", label: "Hugging Face", description: "Free tier - $0.10/mo credits" },
  { value: "replicate", label: "Replicate", description: "Stable Video Diffusion" },
  { value: "runway", label: "Runway", description: "Gen-3 Alpha" },
];

const DIMENSIONS = [
  { label: "Square (512x512)", w: 512, h: 512 },
  { label: "Portrait (576x1024)", w: 576, h: 1024 },
  { label: "Landscape (1024x576)", w: 1024, h: 576 },
  { label: "HD Portrait (720x1280)", w: 720, h: 1280 },
  { label: "HD Landscape (1280x720)", w: 1280, h: 720 },
];

export function VideoGenerator() {
  const router = useRouter();
  const { user, updateCredits } = useUserStore();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [sourceImage, setSourceImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const [form, setForm] = useState({
    prompt: "",
    negativePrompt: "",
    provider: "huggingface",
    width: 512,
    height: 512,
    duration: 5,
    fps: 8,
    seed: undefined as number | undefined,
    cfgScale: 7.0,
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      setSourceImage(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { "image/*": [".png", ".jpg", ".jpeg", ".webp"] },
    maxFiles: 1,
    maxSize: 10 * 1024 * 1024,
  });

  const handleSubmit = async () => {
    if (!user) {
      toast.error("Please sign in to generate videos");
      router.push("/login");
      return;
    }

    if (!form.prompt && !sourceImage) {
      toast.error("Please enter a prompt or upload an image");
      return;
    }

    if (user.credits < 10) {
      toast.error("Insufficient credits. Please purchase more.");
      return;
    }

    setIsSubmitting(true);
    const toastId = toast.loading("Submitting generation request...");

    try {
      const data = new FormData();
      if (form.prompt) data.append("prompt", form.prompt);
      if (form.negativePrompt) data.append("negative_prompt", form.negativePrompt);
      data.append("width", String(form.width));
      data.append("height", String(form.height));
      data.append("duration_seconds", String(form.duration));
      data.append("fps", String(form.fps));
      data.append("provider", form.provider);
      data.append("cfg_scale", String(form.cfgScale));
      if (form.seed !== undefined) data.append("seed", String(form.seed));
      if (sourceImage) data.append("source_image", sourceImage);

      const response = await videoApi.generate(data);
      const generation = response.data;

      updateCredits(user.credits - 10);
      toast.success("Generation started! Check your gallery.", { id: toastId });
      router.push("/gallery");
    } catch (err: any) {
      const msg = err.response?.data?.detail || "Failed to start generation";
      toast.error(msg, { id: toastId });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="space-y-6">
        <Card>
          <CardContent className="p-6 space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Prompt</label>
              <Textarea
                placeholder="Describe the video you want to generate..."
                value={form.prompt}
                onChange={(e) => setForm({ ...form, prompt: e.target.value })}
                rows={4}
                maxLength={1000}
              />
              <p className="text-xs text-muted-foreground mt-1">
                {form.prompt.length}/1000 characters
              </p>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Source Image (optional)</label>
              <div
                {...getRootProps()}
                className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
                  isDragActive ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
                }`}
              >
                <input {...getInputProps()} />
                {previewUrl ? (
                  <div className="relative inline-block">
                    <img src={previewUrl} alt="Preview" className="max-h-48 rounded-lg mx-auto" />
                    <button
                      onClick={(e) => { e.stopPropagation(); setSourceImage(null); setPreviewUrl(null); }}
                      className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-destructive text-white flex items-center justify-center"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2">
                    <Upload className="h-8 w-8 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">
                      Drag & drop an image, or click to browse
                    </p>
                    <p className="text-xs text-muted-foreground">PNG, JPG up to 10MB</p>
                  </div>
                )}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">AI Provider</label>
              <div className="grid grid-cols-2 gap-3">
                {PROVIDERS.map((p) => (
                  <button
                    key={p.value}
                    onClick={() => setForm({ ...form, provider: p.value })}
                    className={`p-3 rounded-lg border text-left transition-colors ${
                      form.provider === p.value
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <div className="font-medium text-sm">{p.label}</div>
                    <div className="text-xs text-muted-foreground">{p.description}</div>
                  </button>
                ))}
              </div>
            </div>

            <Button
              onClick={handleSubmit}
              disabled={isSubmitting || (!form.prompt && !sourceImage)}
              className="w-full gap-2"
              size="lg"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Starting Generation...
                </>
              ) : (
                <>
                  <Wand2 className="h-4 w-4" />
                  Generate Video (10 credits)
                </>
              )}
            </Button>

            {!user && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-yellow-50 text-yellow-800 text-sm">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>Sign in to generate videos. New accounts get 50 free credits.</span>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="space-y-6">
        <Card>
          <CardContent className="p-6">
            <button
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="flex items-center gap-2 text-sm font-medium w-full"
            >
              <Settings2 className="h-4 w-4" />
              Advanced Settings
              {showAdvanced ? <ChevronUp className="h-4 w-4 ml-auto" /> : <ChevronDown className="h-4 w-4 ml-auto" />}
            </button>

            <AnimatePresence>
              {showAdvanced && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <div className="pt-4 space-y-6">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Dimensions</label>
                      <div className="grid grid-cols-2 gap-2">
                        {DIMENSIONS.map((d) => (
                          <button
                            key={d.label}
                            onClick={() => setForm({ ...form, width: d.w, height: d.h })}
                            className={`p-2 rounded-md border text-xs text-left transition-colors ${
                              form.width === d.w && form.height === d.h
                                ? "border-primary bg-primary/5"
                                : "border-border"
                            }`}
                          >
                            {d.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">
                        Duration: {form.duration}s
                      </label>
                      <Slider
                        value={[form.duration]}
                        onValueChange={([v]) => setForm({ ...form, duration: v })}
                        min={1}
                        max={10}
                        step={1}
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">
                        FPS: {form.fps}
                      </label>
                      <Slider
                        value={[form.fps]}
                        onValueChange={([v]) => setForm({ ...form, fps: v })}
                        min={1}
                        max={30}
                        step={1}
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">
                        CFG Scale: {form.cfgScale}
                      </label>
                      <Slider
                        value={[form.cfgScale]}
                        onValueChange={([v]) => setForm({ ...form, cfgScale: v })}
                        min={1}
                        max={20}
                        step={0.5}
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Higher values = stronger prompt adherence
                      </p>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Seed (optional)</label>
                      <input
                        type="number"
                        placeholder="Random"
                        value={form.seed ?? ""}
                        onChange={(e) => {
                          const val = e.target.value;
                          setForm({ ...form, seed: val ? parseInt(val) : undefined });
                        }}
                        className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Negative Prompt</label>
                      <Textarea
                        placeholder="Things to avoid in the video..."
                        value={form.negativePrompt}
                        onChange={(e) => setForm({ ...form, negativePrompt: e.target.value })}
                        rows={2}
                        maxLength={500}
                      />
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950/30 dark:to-purple-950/30">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-3">
              <Clock className="h-5 w-5 text-primary" />
              <h3 className="font-semibold">Estimated Time</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Most generations complete in 2-5 minutes depending on the provider and queue length.
              You will be redirected to your gallery where you can track progress in real-time.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
