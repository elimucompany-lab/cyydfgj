"use client";

import { useState, useEffect, useCallback } from "react";
import { videoApi } from "@/lib/api";
import { VideoGeneration } from "@/types";

export function useGenerations() {
  const [generations, setGenerations] = useState<VideoGeneration[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  const fetchGenerations = useCallback(async (pageNum: number = 1, append: boolean = false) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await videoApi.list({ page: pageNum, limit: 20 });
      const data = response.data;
      if (append) {
        setGenerations((prev) => [...prev, ...data.items]);
      } else {
        setGenerations(data.items);
      }
      setHasMore(pageNum < data.pages);
      setPage(pageNum);
    } catch (err: any) {
      setError(err.response?.data?.detail || "Failed to load videos");
    } finally {
      setIsLoading(false);
    }
  }, []);

  const refresh = useCallback(() => {
    fetchGenerations(1, false);
  }, [fetchGenerations]);

  const loadMore = useCallback(() => {
    if (!isLoading && hasMore) {
      fetchGenerations(page + 1, true);
    }
  }, [isLoading, hasMore, page, fetchGenerations]);

  useEffect(() => {
    fetchGenerations(1, false);
  }, [fetchGenerations]);

  return {
    generations,
    isLoading,
    error,
    hasMore,
    refresh,
    loadMore,
    deleteGeneration: async (id: string) => {
      await videoApi.delete(id);
      setGenerations((prev) => prev.filter((g) => g.id !== id));
    },
  };
}
