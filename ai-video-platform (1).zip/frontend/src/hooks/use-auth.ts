"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useUserStore } from "@/store/user-store";

export function useAuth(requireAuth: boolean = true) {
  const router = useRouter();
  const { user, isLoading, checkAuth } = useUserStore();

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  useEffect(() => {
    if (!isLoading && requireAuth && !user) {
      router.push("/login");
    }
  }, [isLoading, user, requireAuth, router]);

  return { user, isLoading, isAuthenticated: !!user };
}
