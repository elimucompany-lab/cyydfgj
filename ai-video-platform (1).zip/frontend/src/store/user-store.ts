"use client";

import { create } from "zustand";
import { User } from "@/types";
import { authApi } from "@/lib/api";

interface UserState {
  user: User | null;
  isLoading: boolean;
  setUser: (user: User | null) => void;
  checkAuth: () => Promise<void>;
  logout: () => void;
  updateCredits: (credits: number) => void;
}

export const useUserStore = create<UserState>((set) => ({
  user: null,
  isLoading: true,
  setUser: (user) => set({ user }),
  checkAuth: async () => {
    const token = localStorage.getItem("access_token");
    if (!token) {
      set({ isLoading: false, user: null });
      return;
    }
    try {
      const response = await authApi.me();
      set({ user: response.data, isLoading: false });
    } catch {
      localStorage.removeItem("access_token");
      set({ user: null, isLoading: false });
    }
  },
  logout: () => {
    localStorage.removeItem("access_token");
    set({ user: null });
    window.location.href = "/";
  },
  updateCredits: (credits) =>
    set((state) => ({
      user: state.user ? { ...state.user, credits } : null,
    })),
}));
