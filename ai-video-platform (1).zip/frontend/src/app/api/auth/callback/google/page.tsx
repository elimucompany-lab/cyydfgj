"use client";

import { useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import toast from "react-hot-toast";
import { authApi } from "@/lib/api";
import { useUserStore } from "@/store/user-store";
import { Loader2 } from "lucide-react";

function GoogleCallbackInner() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { checkAuth } = useUserStore();

  useEffect(() => {
    const code = searchParams.get("code");
    if (!code) {
      toast.error("Authentication failed");
      router.push("/login");
      return;
    }

    const redirectUri = `${window.location.origin}/api/auth/callback/google`;
    authApi
      .google(code, redirectUri)
      .then((res) => {
        localStorage.setItem("access_token", res.data.access_token);
        checkAuth();
        toast.success("Signed in with Google!");
        router.push("/generate");
      })
      .catch((err) => {
        toast.error(err.response?.data?.detail || "Google sign-in failed");
        router.push("/login");
      });
  }, [searchParams, router, checkAuth]);

  return (
    <div className="flex items-center justify-center h-screen">
      <div className="flex flex-col items-center gap-4">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="text-muted-foreground">Completing sign-in...</p>
      </div>
    </div>
  );
}

export default function GoogleCallbackPage() {
  return (
    <Suspense
      fallback={
        <div className="flex items-center justify-center h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      }
    >
      <GoogleCallbackInner />
    </Suspense>
  );
}
