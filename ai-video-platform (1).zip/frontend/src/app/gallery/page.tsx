"use client";

import { VideoGallery } from "@/components/gallery/video-gallery";

export default function GalleryPage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Your Gallery</h1>
        <p className="text-muted-foreground mt-1">
          Browse, manage, and download your AI-generated videos.
        </p>
      </div>
      <VideoGallery />
    </div>
  );
}
