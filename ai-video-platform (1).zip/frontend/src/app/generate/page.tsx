"use client";

import { VideoGenerator } from "@/components/generate/video-generator";

export default function GeneratePage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Generate Video</h1>
        <p className="text-muted-foreground mt-1">
          Describe your vision or upload an image to create AI-powered videos.
        </p>
      </div>
      <VideoGenerator />
    </div>
  );
}
